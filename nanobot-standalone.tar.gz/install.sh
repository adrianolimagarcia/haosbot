#!/usr/bin/env bash
set -euo pipefail

# nanobot-go standalone installer
# Sets up ~/.nanobot/, workspace templates, systemd user service, and binary in ~/.local/bin/

INSTALL_DIR="${HOME}/.local/bin"
DATA_DIR="${HOME}/.nanobot"
SYSTEMD_DIR="${HOME}/.config/systemd/user"

echo "==> Installing nanobot-go..."

# 1. Ensure directories exist
mkdir -p "${INSTALL_DIR}"
mkdir -p "${DATA_DIR}/workspace"
mkdir -p "${DATA_DIR}/sessions"
mkdir -p "${DATA_DIR}/logs"
mkdir -p "${DATA_DIR}/media"
mkdir -p "${SYSTEMD_DIR}"

# 2. Copy binary
if [ ! -f "./nanobot" ]; then
    echo "Error: ./nanobot binary not found in current directory." >&2
    exit 1
fi
cp ./nanobot "${INSTALL_DIR}/nanobot"
chmod +x "${INSTALL_DIR}/nanobot"
echo "    Installed binary to ${INSTALL_DIR}/nanobot"

# 3. Initialize paths & templates using nanobot itself
export PATH="${INSTALL_DIR}:${PATH}"
nanobot paths || true

# 4. Create systemd user service unit
SERVICE_FILE="${SYSTEMD_DIR}/nanobot.service"
cat << EOF > "${SERVICE_FILE}"
[Unit]
Description=nanobot-go AI Agent Gateway
After=network.target

[Service]
Type=simple
ExecStart=${INSTALL_DIR}/nanobot gateway
Restart=always
RestartSec=5
StandardOutput=append:${DATA_DIR}/logs/gateway.log
StandardError=append:${DATA_DIR}/logs/gateway.err.log

[Install]
WantedBy=default.target
EOF

echo "    Created systemd service at ${SERVICE_FILE}"
echo "==> Installation complete!"
echo ""
echo "To start the gateway service:"
echo "    systemctl --user daemon-reload"
echo "    systemctl --user enable --now nanobot"
echo ""
echo "To check status:"
echo "    systemctl --user status nanobot"
